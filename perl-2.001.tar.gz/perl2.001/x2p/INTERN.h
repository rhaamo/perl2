/* $Header: INTERN.h,v 2.0 88/06/05 00:15:27 root Exp $
 *
 * $Log:	INTERN.h,v $
 * Revision 2.0  88/06/05  00:15:27  root
 * Baseline version 2.0.
 * 
 */

#undef EXT
#define EXT

#undef INIT
#define INIT(x) = x

#define DOINIT
