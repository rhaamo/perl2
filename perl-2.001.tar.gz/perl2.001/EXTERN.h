/* $Header: EXTERN.h,v 2.0 88/06/05 00:07:46 root Exp $
 *
 * $Log:	EXTERN.h,v $
 * Revision 2.0  88/06/05  00:07:46  root
 * Baseline version 2.0.
 * 
 */

#undef EXT
#define EXT extern

#undef INIT
#define INIT(x)

#undef DOINIT
